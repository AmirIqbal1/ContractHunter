module Echidna.Solidity where

import Control.Monad (when, unless, forM_)
import Control.Monad.IO.Class (liftIO)
import Control.Monad.Catch (MonadThrow(..))
import Control.Monad.Extra (whenM)
import Control.Monad.Reader (ReaderT(runReaderT))
import Control.Monad.ST (stToIO)
import Control.Monad.State (runStateT)
import Data.Foldable (toList)
import Data.List (find, partition, isSuffixOf, (\\))
import Data.List.NonEmpty (NonEmpty((:|)))
import Data.List.NonEmpty qualified as NE
import Data.List.NonEmpty.Extra qualified as NEE
import Data.Map (Map)
import Data.Map qualified as Map
import Data.Maybe (isJust, isNothing, catMaybes, listToMaybe, mapMaybe)
import Data.Set (Set)
import Data.Set qualified as Set
import Data.Text (Text, isPrefixOf, isSuffixOf, append)
import Data.Text qualified as T
import Optics.Core hiding (filtered)
import System.Directory
  (doesDirectoryExist, doesFileExist, findExecutable, listDirectory, removeFile)
import System.Exit (ExitCode(..))
import System.FilePath (joinPath, splitDirectories, (</>))
import System.FilePath.Posix qualified as FPP
import System.IO (openFile, IOMode(..))
import System.Info (os)
import System.Process (StdStream(..), readCreateProcessWithExitCode, proc, std_err)

import EVM (initialContract, currentContract)
import EVM.ABI
import EVM.Effects (runApp)
import EVM.Format (showTraceTree)
import EVM.Solidity
import EVM.Types hiding (Env)

import Echidna.ABI
  ( encodeSig, encodeSigWithName, hashSig, fallback
  , commonTypeSizes, mkValidAbiInt, mkValidAbiUInt )
import Echidna.Deploy (deployContracts, deployBytecodes)
import Echidna.Exec (execTx, execTxWithCov, initialVM)
import Echidna.SourceAnalysis.Slither
import Echidna.Test (createTests, isAssertionMode, isPropertyMode, isFoundryMode, isOptimizationMode)
import Echidna.Types.Campaign (CampaignConf(..))
import Echidna.Types.Config (EConfig(..), Env(..))
import Echidna.Types.Signature
  (ContractName, SolSignature, SignatureMap, FunctionName)
import Echidna.Types.Solidity
import Echidna.Types.Test (EchidnaTest(..))
import Echidna.Types.Tx
  ( basicTx, createTxWithValue, unlimitedGasPerBlock, initialTimestamp
  , initialBlockNumber )
import Echidna.Types.World (World(..))
import Echidna.Utility (applyAnsiColor, measureIO)

readSolcBatch :: FilePath -> IO [BuildOutput]
readSolcBatch d = do
  fs <- filter (".json" `Data.List.isSuffixOf`) <$> listDirectory d
  mapM parseOne fs
  where
  parseOne f =
    runApp $ readSolc CombinedJSON "" (d </> f) >>= \case
      Right buildOutput -> pure buildOutput
      Left e ->
        error $ "Failed to parse combined JSON file " <> (d </> f) <> "\n" <> e

-- | Given a list of files, use its extension to check if it is a precompiled
-- contract or try to compile it and get a list of its contracts and a list of source
-- cache, throwing exceptions if necessary.
compileContracts
  :: SolConf
  -> NonEmpty FilePath
  -> IO BuildOutput
compileContracts solConf fp = do
  path <- findExecutable "crytic-compile" >>= \case
    Nothing -> throwM NoCryticCompile
    Just path -> pure path

  let
    usual = ["--solc-disable-warnings", "--export-format", "solc"]
    solargs = solConf.solcArgs ++ linkLibraries solConf.solcLibs & (usual ++) .
              (\sa -> if null sa then [] else ["--solc-args", sa])
    compileOne :: FilePath -> IO BuildOutput
    compileOne x = do
      stderr <- if solConf.quiet
                   then UseHandle <$> openFile nullFilePath WriteMode
                   else pure Inherit
      (ec, out, err) <- measureIO solConf.quiet ("Compiling `" <> x <> "`") $ do
        readCreateProcessWithExitCode
          (proc path $ (solConf.cryticArgs ++ solargs) |> x) {std_err = stderr} ""
      case ec of
        ExitSuccess -> mconcat <$> readSolcBatch "crytic-export"
        ExitFailure _ -> throwM $ CompileFailure out err

    -- | OS-specific path to the "null" file, which accepts writes without storing them
    nullFilePath :: String
    nullFilePath = if os == "mingw32" then "\\\\.\\NUL" else "/dev/null"
  -- clean up previous artifact files
  removeJsonFiles "crytic-export"
  mconcat . NE.toList <$> mapM compileOne fp

removeJsonFiles :: FilePath -> IO ()
removeJsonFiles dir =
  whenM (doesDirectoryExist dir) $ do
    files <- listDirectory dir
    forM_ files $ \file ->
      when (".json" `Data.List.isSuffixOf` file) $ do
        let path = dir </> file
        whenM (doesFileExist path) $ removeFile path

staticAddresses :: SolConf -> Set AbiValue
staticAddresses SolConf{contractAddr, deployer, sender} =
  Set.map AbiAddress $
    Set.union sender (Set.fromList [contractAddr, deployer, 0x0])

populateAddresses :: Set Addr -> Integer -> VM Concrete -> VM Concrete
populateAddresses addrs b vm =
  Set.foldl' (\vm' addr ->
    if deployed addr
       then vm'
       else vm' & set (#env % #contracts % at (LitAddr addr)) (Just account)
  ) vm addrs
  where
    account =
      initialContract (RuntimeCode (ConcreteRuntimeCode mempty))
        & set #nonce (Just 0)
        & set #balance (Lit $ fromInteger b)
    deployed addr = LitAddr addr `Map.member` vm.env.contracts

-- | Address to load the first library
addrLibrary :: Addr
addrLibrary = 0xff

-- | Generate a string to use as argument in solc to link libraries starting from addrLibrary
linkLibraries :: [String] -> String
linkLibraries [] = ""
linkLibraries ls = "--libraries " ++
  concatMap (\(i,x) -> concat [x, ":", show $ addrLibrary + i, ","]) (zip [0..] ls)

-- | Filter methods using a whitelist/blacklist
filterMethods :: Text -> Filter -> NonEmpty SolSignature -> [SolSignature]
filterMethods _ f@(Whitelist [])  _ = error $ show $ InvalidMethodFilters f
filterMethods contractName (Whitelist ic) ms =
  NE.filter (\s -> encodeSigWithName contractName s `elem` ic) ms
filterMethods contractName (Blacklist ig) ms =
  NE.filter (\s -> encodeSigWithName contractName s `notElem` ig) ms

-- | Filter methods for foundry mode. Per Foundry conventions:
-- - Functions prefixed with "test" are test functions (unit or fuzz).
--   Fuzz tests are distinguished by having at least one parameter.
--   See: https://book.getfoundry.sh/forge/fuzz-testing
-- - Functions prefixed with "invariant_" are invariant tests, called in
--   randomized sequences to verify properties that must always hold.
--   See: https://book.getfoundry.sh/forge/invariant-testing
-- - Other functions with arguments are kept as callable targets for
--   invariant test campaigns.
filterMethodsWithArgs :: NonEmpty SolSignature -> NonEmpty SolSignature
filterMethodsWithArgs ms =
  case NE.filter (\(n, xs) -> T.isPrefixOf "test" n || (T.isPrefixOf "invariant_" n || not (null xs))) ms of
    [] -> error "No foundry tests found"
    fs -> NE.fromList fs

abiOf :: Text -> SolcContract -> NonEmpty SolSignature
abiOf pref solcContract =
  fallback :|
    filter (not . isPrefixOf pref . fst)
           (Map.elems solcContract.abiMap <&> \method -> (method.name, snd <$> method.inputs))

-- | Given an optional contract name and a list of 'SolcContract's, try to load the specified
-- contract, or, if not provided, the first contract in the list, into a 'VM' usable for Echidna
-- testing and extract an ABI and list of tests. Throws exceptions if anything returned doesn't look
-- usable for Echidna. NOTE: Contract names passed to this function should be prefixed by the
-- filename their code is in, plus a colon.
loadSpecified
  :: Env
  -> SolcContract
  -> [SolcContract]
  -> IO (VM Concrete)
loadSpecified env mainContract cs = do
  let solConf = env.cfg.solConf

  -- Set up initial VM with chosen contract
  -- need to use snd to add to ABI dict
  initVM <- stToIO $ initialVM solConf.allowFFI
  let vm = initVM & #block % #gaslimit .~ unlimitedGasPerBlock
                  & #block % #maxCodeSize .~ fromIntegral solConf.codeSize

  let blank = populateAddresses (Set.insert solConf.deployer solConf.sender)
                                solConf.balanceAddr vm

  unless (null mainContract.constructorInputs) $
    throwM $ ConstructorArgs (show mainContract.constructorInputs)

  -- Select libraries
  ls <- mapM (chooseContract cs . Just . T.pack) solConf.solcLibs

  flip runReaderT env $ do
    -- library deployment
    vm0 <- deployContracts (zip [addrLibrary ..] ls) solConf.deployer blank

    -- additional contract deployment (by name)
    cs' <- mapM ((chooseContract cs . Just) . T.pack . snd) solConf.deployContracts
    vm1 <- deployContracts (zip (map fst solConf.deployContracts) cs') solConf.deployer vm0

    -- additional contract deployment (bytecode)
    vm2 <- deployBytecodes solConf.deployBytecodes solConf.deployer vm1

    -- main contract deployment
    let
      coverageEnabled = isJust env.cfg.campaignConf.knownCoverage
      deployTx = createTxWithValue
                    mainContract.creationCode
                    solConf.deployer
                    solConf.contractAddr
                    unlimitedGasPerBlock
                    (fromIntegral solConf.balanceContract)
                    (0, 0)
      deployment = if coverageEnabled then snd <$> runStateT (execTxWithCov deployTx) vm2 else snd <$> execTx vm2 deployTx

    vm3 <- deployment
    when (isNothing $ currentContract vm3) $
      throwM $ DeploymentFailed solConf.contractAddr $
        applyAnsiColor env.useColor (showTraceTree env.dapp vm3)

    -- Run setUp function
    let
      abi = Map.elems mainContract.abiMap <&> \method -> (method.name, snd <$> method.inputs)
      transaction = execTx vm3 $ uncurry basicTx
                                           setUpFunction
                                           solConf.deployer
                                           solConf.contractAddr
                                           unlimitedGasPerBlock
                                           (0, 0)
    -- Call setUp() for any contract that has IS_TEST() in its ABI, regardless of
    -- test mode. Contracts following the Foundry/dapptools convention (IS_TEST)
    -- expect setUp() to run even in assertion or property mode.
    when (isFoundryMode solConf.testMode && is_testFunction `notElem` abi) $
      liftIO $ putStrLn "Warning: running in Foundry mode but contract does not have IS_TEST(). setUp() will not be called."
    vm4 <- if is_testFunction `elem` abi && setUpFunction `elem` abi
              then snd <$> transaction
              else pure vm3

    case vm4.result of
      Just (VMFailure _) -> throwM $ SetUpCallFailed $
        applyAnsiColor env.useColor (showTraceTree env.dapp vm4)
      _ -> pure vm4

  where
    setUpFunction = ("setUp", [])
    is_testFunction = ("IS_TEST", [])


selectMainContract
  :: SolConf
  -> Maybe ContractName
  -> [SolcContract]
  -> IO SolcContract
selectMainContract solConf name cs = do
  -- Pick contract to load
  mainContract <- chooseContract cs name
  when (isNothing name && length cs > 1 && not solConf.quiet) $
    putStrLn "Multiple contracts found, only analyzing the first"
  unless solConf.quiet $
    putStrLn $ "Analyzing contract: " <> T.unpack mainContract.contractName
  when (mainContract.creationCode == mempty) $
    throwM (NoBytecode mainContract.contractName)
  pure mainContract

mkSignatureMap
  :: SolConf
  -> SolcContract
  -> [SolcContract]
  -> IO SignatureMap
mkSignatureMap solConf mainContract contracts = do
  let
    -- Optionally exclude view/pure functions from the ABI, but never
    -- exclude prefixed functions (e.g. echidna_*) as they may be properties
    filterViewPure contract sigs
      | solConf.excludeViewPure =
          let viewPureNames = map (.name) $ filter (\m -> m.mutability == View || m.mutability == Pure)
                                                   (Map.elems contract.abiMap)
          in NE.filter (\(n, _) -> isPrefixOf solConf.prefix n || n `notElem` viewPureNames) sigs
      | otherwise = NE.toList sigs
    -- Filter ABI according to the config options
    fabiOfc = if isFoundryMode solConf.testMode
                then NE.toList $ filterMethodsWithArgs (abiOf solConf.prefix mainContract)
                else let base = filterMethods mainContract.contractName solConf.methodFilter $
                                  abiOf solConf.prefix mainContract
                     in case NE.nonEmpty base of
                       Just ne -> filterViewPure mainContract ne
                       Nothing -> base
    -- Construct ABI mapping for World
    abiMapping =
      if solConf.allContracts then
        Map.fromList $ mapMaybe (\contract ->
            let filtered = filterMethods contract.contractName
                                         solConf.methodFilter
                                         (abiOf solConf.prefix contract)
                filtered' = case NE.nonEmpty filtered of
                  Just ne -> filterViewPure contract ne
                  Nothing -> filtered
            in (contract.runtimeCodehash,) <$> NE.nonEmpty filtered')
          contracts
      else
        case NE.nonEmpty fabiOfc of
          Just ne -> Map.singleton mainContract.runtimeCodehash ne
          Nothing -> mempty
  when (null abiMapping && isFoundryMode solConf.testMode) $
    throwM NoTests
  when (Map.null abiMapping) $
    throwM $ InvalidMethodFilters solConf.methodFilter
  pure abiMapping

mkTests
  :: SolConf
  -> CampaignConf
  -> SolcContract
  -> IO [EchidnaTest]
mkTests solConf campaignConf mainContract = do
  let
    -- generate the complete abi mapping
    abi = Map.elems mainContract.abiMap <&> \method -> (method.name, snd <$> method.inputs)
    (tests, funs) = partition (isPrefixOf solConf.prefix . fst) abi
    -- Filter again for foundry tests or assertions checking if enabled
    neFuns' = filterMethods mainContract.contractName
                            solConf.methodFilter
                            (fallback NE.:| funs)
    neFuns = if solConf.excludeViewPure
             then let viewPureNames = map (.name) $ filter (\m -> m.mutability == View || m.mutability == Pure)
                                                           (Map.elems mainContract.abiMap)
                  in filter (\(n, _) -> isPrefixOf solConf.prefix n || n `notElem` viewPureNames) neFuns'
             else neFuns'
    testNames = fst <$> tests

  when (null abi) $
    throwM NoFuncs
  when (null tests && isPropertyMode solConf.testMode) $
    throwM NoTests

  case find (not . null . snd) tests of
    Just (t, _) -> throwM $ TestArgsFound t
    Nothing -> pure ()

  -- Check that property functions return bool
  when (isPropertyMode solConf.testMode) $
    forM_ (Map.elems mainContract.abiMap) $ \method ->
      when (solConf.prefix `T.isPrefixOf` method.name && map snd method.output /= [AbiBoolType]) $
        throwM $ PropertyWithoutReturn method.name

  -- Check that optimization functions return int256
  when (isOptimizationMode solConf.testMode) $
    forM_ (Map.elems mainContract.abiMap) $ \method ->
      when (solConf.prefix `T.isPrefixOf` method.name && map snd method.output /= [AbiIntType 256]) $
        throwM $ OptimizationWithWrongReturn method.name

  pure $ createTests solConf.testMode
                     solConf.testDestruction
                     testNames
                     campaignConf.seqLen
                     solConf.contractAddr
                     neFuns

-- | Given a list of contracts and a requested contract name, pick a contract.
-- See 'loadSpecified' for more information.
chooseContract :: (MonadThrow m) => [SolcContract] -> Maybe Text -> m SolcContract
chooseContract [] _ = throwM NoContracts
chooseContract (c:_) Nothing = pure c
chooseContract cs (Just n) =
  maybe (throwM $ ContractNotFound n) pure $
    find isMatch cs
  where
    isMatch s =
      (Data.Text.isSuffixOf (contractId rewriteOsPathSeparators) . (.contractName)) s ||
      (Data.Text.isSuffixOf (contractId rewritePosixPathSeparators) . (.contractName)) s
    contractId rewrite
      | T.any (== ':') n =
        let (splitPath, splitName) = T.breakOn ":" n
        in rewrite splitPath `T.append` splitName
      | otherwise = ":" `append` n

    rewriteOsPathSeparators = T.pack . joinPath . splitDirectories . T.unpack
    rewritePosixPathSeparators = T.pack . FPP.joinPath . FPP.splitDirectories . T.unpack

-- | Given the results of 'loadSolidity', assuming a single-contract test, get everything ready
-- for running a 'Campaign' against the tests found.
mkWorld
  :: SolConf
  -> SignatureMap
  -> Maybe ContractName
  -> SlitherInfo
  -> [SolcContract]
  -> World
mkWorld SolConf{sender, testMode, excludeViewPure} sigMap maybeContract slitherInfo contracts =
  let
    eventMap = Map.unions $ map (.eventMap) contracts
    payableSigs = filterResults maybeContract slitherInfo.payableFunctions
    assertSigs = filterResults maybeContract (assertFunctionList <$> slitherInfo.asserts)
    as = if isAssertionMode testMode then filterResults maybeContract (assertFunctionList <$> slitherInfo.asserts) else []
    cs = if isFoundryMode testMode || excludeViewPure then [] else filterResults maybeContract slitherInfo.constantFunctions \\ as
    (highSignatureMap, lowSignatureMap) = prepareHashMaps cs as $
      filterFallbacks slitherInfo.fallbackDefined slitherInfo.receiveDefined contracts sigMap
  in World { senders = sender
           , highSignatureMap
           , lowSignatureMap
           , payableSigs
           , assertSigs
           , eventMap
           }

-- | This function is used to filter the lists of function names according to the supplied
-- contract name (if any) and returns a list of hashes
filterResults :: Maybe ContractName -> Map ContractName [FunctionName] -> [FunctionSelector]
filterResults (Just contractName) rs =
  case Map.lookup contractName rs of
    Nothing -> filterResults Nothing rs
    Just sig -> hashSig <$> sig
filterResults Nothing rs = hashSig <$> (concat . Map.elems) rs

filterFallbacks
  :: [ContractName]
  -> [ContractName]
  -> [SolcContract]
  -> SignatureMap
  -> SignatureMap
filterFallbacks la lb contracts = Map.mapWithKey f
  where
    f k ss | k `elem` keysToIgnore = ss
    f _ ss = NE.fromList $ case NE.filter (/= fallback) ss of
                []  -> [fallback] -- No other alternative
                ss' -> ss'
    keysToIgnore = concatMap contractNameToCodehashes (la ++ lb)
    contractNameToCodehashes name = map (.runtimeCodehash) $ filter (\c -> last (T.splitOn ":" c.contractName) == name) contracts

prepareHashMaps
  :: [FunctionSelector]
  -> [FunctionSelector]
  -> SignatureMap
  -> (SignatureMap, Maybe SignatureMap)
prepareHashMaps [] _  m = (m, Nothing) -- No constant functions detected
prepareHashMaps cs as m =
  let
    (hm, lm) =
      ( Map.unionWith NEE.union (filterHashMap not cs m) (filterHashMap id as m)
      , filterHashMap id cs m )
  in
    if | Map.size hm > 0  && Map.size lm > 0  -> (hm, Just lm) -- Usual case
       | Map.size hm > 0  && Map.size lm == 0 -> (hm, Nothing) -- No low-priority functions detected
       | Map.size hm == 0 && Map.size lm > 0  -> (m,  Nothing) -- No high-priority functions detected
       | otherwise                        -> error "Error processing function hashmaps"
  where
    filterHashMap f xs =
      Map.mapMaybe (NE.nonEmpty . NE.filter (\s -> f $ (hashSig . encodeSig $ s) `elem` xs))

mkLargeAbiInt :: Int -> AbiValue
mkLargeAbiInt i = AbiInt i $ 2 ^ (i - 1) - 1

mkLargeAbiUInt :: Int -> AbiValue
mkLargeAbiUInt i = AbiUInt i $ 2 ^ i - 1

mkSmallAbiInt :: Int -> AbiValue
mkSmallAbiInt i = AbiInt i $ -(2 ^ (i - 1))

timeConstants :: Set AbiValue
timeConstants = Set.fromList $ concatMap dec [initialTimestamp, initialBlockNumber]
  where dec i = let l f = f <$> commonTypeSizes <*> fmap fromIntegral [i-1..i+1] in
                catMaybes (l mkValidAbiInt ++ l mkValidAbiUInt)

extremeConstants :: Set AbiValue
extremeConstants =
  Set.unions $
    (\i -> Set.fromList [mkSmallAbiInt i, mkLargeAbiInt i, mkLargeAbiUInt i]) <$> commonTypeSizes

returnTypes :: [SolcContract] -> Text -> Maybe AbiType
returnTypes cs t = do
  method <- find ((== t) . (.name)) $ concatMap (toList . (.abiMap)) cs
  (_, abiType) <- listToMaybe method.output
  pure abiType
