module Echidna.Types.Config where

import Control.Concurrent (Chan)
import Data.Aeson.Key (Key)
import Data.IORef (IORef)
import Data.Set (Set)
import Data.Text (Text)
import Data.Time (LocalTime)
import Data.Word (Word64)

import EVM.Dapp (DappInfo)
import EVM.Fetch qualified as Fetch
import EVM.Types (Addr, W256)

import Echidna.SourceAnalysis.Slither (SlitherInfo)
import Echidna.SourceMapping (CodehashMap)
import Echidna.Types.Cache
import Echidna.Types.Campaign (CampaignConf)
import Echidna.Types.Corpus (Corpus)
import Echidna.Types.Coverage (CoverageMap)
import Echidna.Types.Solidity (SolConf)
import Echidna.Types.Test (TestConf, EchidnaTest)
import Echidna.Types.Tx (TxConf)
import Echidna.Types.Worker (CampaignEvent)
import Echidna.Types.World (World)

data OperationMode = Interactive | NonInteractive OutputFormat deriving (Show, Eq)
data OutputFormat = Text | JSON | None deriving (Show, Eq)
data UIConf = UIConf { maxTime       :: Maybe Int
                     , operationMode :: OperationMode
                     }

-- | An address involved with a 'Transaction' is either the sender, the recipient, or neither of those things.
data Role = Sender | Receiver

-- | Rules for pretty-printing addresses based on their role in a transaction.
type Names = Role -> Addr -> String

-- | Our big glorious global config type, just a product of each local config.,
data EConfig = EConfig
  { campaignConf :: CampaignConf
  , namesConf :: Names
  , solConf :: SolConf
  , testConf :: TestConf
  , txConf :: TxConf
  , uiConf :: UIConf

  , allEvents :: Bool
  , rpcUrl :: Maybe Text
  , rpcBlock :: Maybe Word64
  , etherscanApiKey :: Maybe Text
  , projectName :: Maybe Text
  , disableOnchainSources :: Bool
  }

instance Read OutputFormat where
  readsPrec _ =
    \case 't':'e':'x':'t':r -> [(Text, r)]
          'j':'s':'o':'n':r -> [(JSON, r)]
          'n':'o':'n':'e':r -> [(None, r)]
          _ -> []


data EConfigWithUsage = EConfigWithUsage
  { econfig   :: EConfig
  , badkeys   :: Set Key
  , unsetkeys :: Set Key
  }

data Env = Env
  { cfg :: EConfig
  , dapp :: DappInfo

  -- | Whether stdout supports ANSI escape codes. Detected once at startup;
  -- false when output is redirected to a file or pipe so traces can be
  -- saved without unrenderable color codes.
  , useColor :: Bool

  -- | Shared between all workers. Events are fairly rare so contention is
  -- minimal.
  , eventQueue :: Chan (LocalTime, CampaignEvent)

  , testRefs :: [IORef EchidnaTest]
  , coverageRefInit :: IORef CoverageMap
  , coverageRefRuntime :: IORef CoverageMap
  , corpusRef :: IORef Corpus

  , slitherInfo :: Maybe SlitherInfo
  , codehashMap :: CodehashMap
  , fetchSession :: Fetch.Session
  , contractNameCache :: IORef ContractNameCache
  , chainId :: Maybe W256
  , world :: World
  }
