contract Abstract {}
